export const firebaseConfig = {
  "projectId": "studio-8133147340-863c4",
  "appId": "1:868364663973:web:c023563fbf711e4c50614c",
  "apiKey": "AIzaSyA9nnKPtelRgAzNk1JY0zw4wEtQUQFjb9s",
  "authDomain": "studio-8133147340-863c4.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "868364663973"
};
