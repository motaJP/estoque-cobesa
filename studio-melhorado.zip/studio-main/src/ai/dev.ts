import { config } from 'dotenv';
config();

import '@/ai/flows/generate-reorder-plan.ts';
import '@/ai/flows/find-compatible-parts-flow.ts';
